src/Way_Lock_Core0.o: ../src/Way_Lock_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example1_Core0\system/adi_initialize.h \
 ../src/Way_Lock_Core0.h

D:\Work\AppNote_Examplesfinal\Example1_Core0\system/adi_initialize.h:

../src/Way_Lock_Core0.h:
