################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Way_Lock_Core0.c 

SRC_OBJS += \
./src/Way_Lock_Core0.o 

C_DEPS += \
./src/Way_Lock_Core0.d 


# Each subdirectory must supply rules for building sources it contributes
src/Way_Lock_Core0.o: ../src/Way_Lock_Core0.c
	@echo 'Building file: $<'
	@echo 'Invoking: CrossCore ARM Bare Metal C Compiler'
	arm-none-eabi-gcc -g -gdwarf-2 -ffunction-sections -fdata-sections -DCORE0 -D_DEBUG -DADI_MCAPI -I"D:\Work\AppNote_Examplesfinal\Example1_Core0\system" -Wall -c -mproc=ADSP-SC589 -msi-revision=1.0 -MMD -MP -MF"src/Way_Lock_Core0.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


