/*****************************************************************************
 * Way_Lock_Core0.h
 *****************************************************************************/

#ifndef __WAY_LOCK_CORE0_H__
#define __WAY_LOCK_CORE0_H__

/* Add your custom header content here */

#endif /* __WAY_LOCK_CORE0_H__ */
