/*****************************************************************************
 * Example5_Core0.h
 *****************************************************************************/

#ifndef __EXAMPLE5_CORE0_H__
#define __EXAMPLE5_CORE0_H__

/* Add your custom header content here */

#endif /* __EXAMPLE5_CORE0_H__ */
