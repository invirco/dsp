src/Example5_Core0.o: ../src/Example5_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example5_Core0\system/adi_initialize.h \
 ../src/Example5_Core0.h

D:\Work\AppNote_Examplesfinal\Example5_Core0\system/adi_initialize.h:

../src/Example5_Core0.h:
