/*****************************************************************************
 * Capacity_Miss_Cache_Core0.h
 *****************************************************************************/

#ifndef __CAPACITY_MISS_CACHE_CORE0_H__
#define __CAPACITY_MISS_CACHE_CORE0_H__

/* Add your custom header content here */

#endif /* __CAPACITY_MISS_CACHE_CORE0_H__ */
