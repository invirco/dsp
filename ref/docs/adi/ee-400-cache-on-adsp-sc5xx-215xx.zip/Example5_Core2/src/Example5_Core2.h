/*****************************************************************************
 * Example5_Core2.h
 *****************************************************************************/

#ifndef __EXAMPLE5_CORE2_H__
#define __EXAMPLE5_CORE2_H__

/* Add your custom header content here */

#endif /* __EXAMPLE5_CORE2_H__ */
