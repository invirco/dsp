src/Example5_Core2.doj: ../src/Example5_Core2.c
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cdefSC589.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cdef215xx_core.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdint.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/yvals.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/def215xx_core.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/defSC589.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP-SC58x.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/defSC58x_id_macros.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC5xx_legacy.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC58x_cdef.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/processor_include.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/SC589.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/adi_core.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cache.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdbool.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/builtins.h
src/Example5_Core2.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/builtins_support.h
src/Example5_Core2.doj: ../system/adi_initialize.h
src/Example5_Core2.doj: ../src/Example5_Core2.h
