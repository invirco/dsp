.section .executable_name;
.byte _executable_name.[] = 'Example5_Core2.dxe',0;

