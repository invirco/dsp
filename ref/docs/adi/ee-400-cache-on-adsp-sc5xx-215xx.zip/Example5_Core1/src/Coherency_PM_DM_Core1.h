/*****************************************************************************
 * Coherency_PM_DM_Core1.h
 *****************************************************************************/

#ifndef __COHERENCY_PM_DM_CORE1_H__
#define __COHERENCY_PM_DM_CORE1_H__

/* Add your custom header content here */

#define L2_START_ADDRES1 0x200B0000
#define SIZE 0x1000

#endif /* __COHERENCY_PM_DM_CORE1_H__ */
