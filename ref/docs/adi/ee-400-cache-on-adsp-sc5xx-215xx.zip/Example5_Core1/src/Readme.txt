

This project demonstrates the DM-PM coherency for Cache in the hardware and an example to show the
performance impact when DM and PM data types are mixed.

This code works as follows:

1) Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.

a) DM_PM_Incoherency: 

When DM bus accesses an address, after cache miss this address is stored in DM Cache. If PM bus accesses the 
same address, this results in cache miss in the native PM cache and a cross-check hit in the non-native DM cache.
This cross-check hit causes a performance impact.

b) DM_PM_Coherency: 

The same address is accessed by DM bus results in a performance comparable to L1 when the data is available 
in the native cache.

c) PM_DM_Incoherency & PM_DM_Coherency:

A similar example to demonstrate DM-PM Coherency for PM Cache

In conclusion, performance impact may occur in mixing the DM and PM data types.


NOTE-

Please ensure that you don't place breakpoints or add any additional printf statements apart from 
the used while running the code as these result in cache flush and could result in errors.


