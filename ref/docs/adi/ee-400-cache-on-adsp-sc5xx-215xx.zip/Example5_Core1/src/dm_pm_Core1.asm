#include "Coherency_PM_DM_Core1.h"

.extern cycles_start1.,cycles_end1.,cycles_start2.,cycles_end2.,cycles_start3.,cycles_end3.,cycles_start4.,cycles_end4.,save_i4.,save_r4.;

.section/SW  seg_swco;

DM_PM_Incoherency.:

	i2=0x200B0000;
	m2=1;
	r2 = 0xADBCADBC;
	lcntr = 0x1000, do loop1 until lce;  
loop1:	dm(i2,m2) = r2;
	sync;

	i9=0x200B0000;
	m9=2;
	dm(cycles_start1.) = emuclk;
	lcntr = 0x1000, do loop2 until lce;  
loop2:	r6 = pm(i9,m9);
	dm(cycles_end1.) = emuclk;
	
	
	i12=dm(m7,i6);
	jump (m14,i12) (db); rframe; nop;	
	
.DM_PM_Incoherency..end:


DM_PM_Coherency.:

	i2=0x200B4000;
	m2=1;
	r2 = 0x900DFEED;
	lcntr = 0x1000, do test_loop until lce;  
test_loop:		dm(i2,m2) = r2;
	sync;

	i2=0x200B4000;
	dm(cycles_start2.) = emuclk;
	lcntr = 0x1000, do test_loop1 until lce;  
test_loop1:	r6 = dm(i2,m2);
	dm(cycles_end2.) = emuclk;
	

	i12=dm(m7,i6);
	jump (m14,i12) (db); rframe; nop;	
	
.DM_PM_Coherency..end:

	
PM_DM_Incoherency.:

	i9=0x200B0000;
	m9=1;
	r2 = 0xBCADADBC;
	lcntr = 0x1000, do loopa1 until lce;  
loopa1:	pm(i9,m9) = r2;
	sync;

	i2=0x200B0000;
	m2=2;
	dm(cycles_start3.) = emuclk;
	lcntr = 0x1000, do loopb1 until lce;  
loopb1:	r6 = dm(i2,m2);
	dm(cycles_end3.) = emuclk;
	
	
	i12=dm(m7,i6);
	jump (m14,i12) (db); rframe; nop;	
	
.PM_DM_Incoherency..end:


PM_DM_Coherency.:

	i9=0x200B4000;
	m9=1;
	r2 = 0x0BADFEED;
	lcntr = 0x1000, do test_loopa until lce;  
test_loopa:		pm(i9,m9) = r2;
	sync;

	i9=0x200B4000;
	m9=1;
	dm(cycles_start4.) = emuclk;
	lcntr = 0x1000, do test_loopb until lce;  
test_loopb:	r6 = pm(i9,m9);
	dm(cycles_end4.) = emuclk;
	

	i12=dm(m7,i6);
	jump (m14,i12) (db); rframe; nop;	
	
.PM_DM_Coherency..end:
	

		.global DM_PM_Incoherency.;
		.type DM_PM_Incoherency., STT_FUNC;

		.global DM_PM_Coherency.;
		.type DM_PM_Coherency., STT_FUNC;
		
		.global PM_DM_Incoherency.;
		.type PM_DM_Incoherency., STT_FUNC;

		.global PM_DM_Coherency.;
		.type PM_DM_Coherency., STT_FUNC;
