/*****************************************************************************
 * Coherency_PM_DM_Core1.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "Coherency_PM_DM_Core1.h"
#include <stdio.h>
#include <sys/cache.h>

void DM_PM_Incoherency(void);
void DM_PM_Coherency(void);
void dcache_invalidate_both(int writeback);

unsigned cycles_start1,cycles_end1,cycles_start2,cycles_end2,cycles_start3,cycles_end3,cycles_start4,cycles_end4,save_i4, save_r4;
int count1,count2,count3,count4;

/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();
	
	printf("\n\nDM-PM CrossCheck Hit: Avoid accessing a location first through DM bus and then through PM bus or vice versa\n\n");

	/* Begin adding your custom code here */
	DM_PM_Incoherency();
	count1 = cycles_end1 - cycles_start1;

	printf("Average cycles taken per access in non-native cache (Crosscheck Hits):%d\n\n",count1/0x1000);


	DM_PM_Coherency();
	count2 = cycles_end2 - cycles_start2;


	printf("Average cycles taken per access in native DM cache (No Crosscheck): %d\n\n",count2/0x1000);



	PM_DM_Incoherency();
	count3 = cycles_end3 - cycles_start3;

	printf("Average cycles taken per access in non-native cache (Crosscheck Hits): %d\n\n",count3/0x1000);


	PM_DM_Coherency();
	count4 = cycles_end4 - cycles_start4;

	printf("Average cycles taken per access in native PM cache (No Crosscheck): %d\n",count4/0x1000);


	return 0;
}

