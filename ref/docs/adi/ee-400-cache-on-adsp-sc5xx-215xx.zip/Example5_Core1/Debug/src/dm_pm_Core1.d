src/dm_pm_Core1.doj: ../src/dm_pm_Core1.asm
src/dm_pm_Core1.doj: ../src/Coherency_PM_DM_Core1.h
