.section .executable_name;
.byte _executable_name.[] = 'Example5_Core1.dxe',0;

