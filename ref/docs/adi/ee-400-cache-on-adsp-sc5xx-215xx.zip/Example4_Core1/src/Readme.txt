

This code shows the Range-based invalidation feature of Cache.

The code works as follows.

1. Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.
2. Core accesses L2 with cache enabled results in cache fill(both the ways). All the lines will be valid
3. Address-Range based cache invalidation results in certain cache line contents as invalid.
4. Cache flush of the entire buffer range is performed using flush_data_buffer
5. The contents after flush are compared with the expected value


NOTE-

Please ensure that you don't place breakpoints or add any additional printf statements apart from 
the used while running the code as these result in Cache flush and could result in errors.
