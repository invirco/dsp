/*****************************************************************************
 * Addr_based_Cache_Inv_Core1.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "Addr_based_Cache_Inv_Core1.h"
#include <cycle_count.h>
#include <sys/cache.h>
#include <stdio.h>

int pass_count = 0;
int err_count,err_count1,err_count2 = 0;

char __argv_string[] = "";

#define SIZE 16384 //(16KB)

uint8_t Check_Buffer[SIZE];//Make sure it is in Internal memory
uint8_t Check_Buffer1[SIZE];
uint8_t Check_Buffer2[SIZE];
uint8_t Check_Buffer3[SIZE];

int main(int argc, char *argv[])
{
	int i;

	adi_initComponents();

	cycle_t start_count1,final_count1,start_count2,final_count2,start_count3,final_count3;

	//Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.
	//L2 Accesses with Cache ON and fill the entire cache (Both the ways) . All the lines will be valid
	uint8_t * pL2_Buf1;
	pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

	//Cycle count will be more as there will be few Cache misses as core writes to L2
	START_CYCLE_COUNT(start_count1);
	for(i=0;i<SIZE;i++)
	{
		*pL2_Buf1 = 0xFA;
		pL2_Buf1++;
	}
	STOP_CYCLE_COUNT(final_count1,start_count1);


	//Check the L2 range : It should not contain the correct data as the data is still in cache
	// Address from 0x200c0000 to 0x200c3fff should be zero as the data in Cache
	MDMA0_Write((uint8_t *)L2_START_ADDRES1,(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE);
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value
	for(i=0;i<SIZE;i++)
	{
		if(Check_Buffer[i] != 0xFA)
		{
			pass_count++;
		}
		else
			err_count++;
	}

	if(pass_count != (SIZE))
	{
		printf("Error \n");
		return 0;
	}

	pass_count = 0;
	err_count=0;
/*
 * Address based Cache Invalidation
*/

	*pREG_SHL1C0_CFG2 |= (BITM_SHL1C_CFG2_RR0EN | BITM_SHL1C_CFG2_RR0SEL) ;
	*pREG_SHL1C0_RANGE_START0 = INV_START;
	*pREG_SHL1C0_RANGE_END0 = INV_END;
	asm volatile ("NOP;NOP;NOP;NOP;NOP;NOP;NOP;NOP;NOP;NOP;NOP;NOP;");

	int invcnt = *pREG_SHL1C0_INV_CNT0;
	int j = 0;
	for ( j = 0; j<invcnt ; j++)
	{
			asm volatile ("INVALIDATE DM_CACHE;");
	}


	// Address from 0x200c0000 to 0x200c0fff should not have the correct values after invalidate
	MDMA0_Write((uint8_t *)(INV_START),(uint8_t *)((uint32_t)Check_Buffer1|(uint32_t)0x28000000),(INV_END-INV_START));
	while(DMA_Completed == 0);
	DMA_Completed = 0;



	//Compare the contents of Check buffer with the expected value
	for(i=0;i<SIZE/4;i++)
	{
		if(Check_Buffer1[i] != 0xFA)
		{
			pass_count++;
		}
		else
			err_count1++;
	}

	if(pass_count != (SIZE/4))
	{
		printf("Error : Address range based Invalidation incomplete \n");
		return 0;
	}
	pass_count = 0;


	for(i=0;i<SIZE;i++)
	{
		Check_Buffer2[i] = 0;
	}

	flush_data_buffer(L2_START_ADDRES1, L2_START_ADDRES1+SIZE, ADI_FLUSH_DATA_INV);

	MDMA0_Write((uint8_t *)(L2_START_ADDRES1),(uint8_t *)((uint32_t)Check_Buffer3|(uint32_t)0x28000000),(SIZE/4));
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	for(i=0;i<(SIZE/4);i++)
		{
			if(Check_Buffer3[i] != 0xFA)
			{
				pass_count++;
			}
			else
				err_count2++;
		}

	if(pass_count != (SIZE/4))
		{
			printf("Error : Range based invalidate incomplete\n");
			return 0;
		}
	pass_count = 0;
	err_count2 = 0;

	// Address from 0x200c1000 to 0x200c3fff should have the updated values after Cache Flush
	MDMA0_Write((uint8_t *)(L2_START_ADDRES1+(SIZE/4)),(uint8_t *)((uint32_t)Check_Buffer2|(uint32_t)0x28000000),(3*SIZE/4));
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value

	for(i=0;i<(3*SIZE/4);i++)
	{
		if(Check_Buffer2[i] == 0xFA)
		{
			pass_count++;
		}
		else
			err_count2++;
	}
	if(pass_count != (3*SIZE/4))
	{
		printf("Error : Range based Flush incomplete\n");
		return 0;
	}

	printf("\n\nTest Passed : Range Based Flush feature working as expected\n");
	printf("No. of lines invalidated : %d\n",invcnt);


	return 0;
}

