src/Addr_based_Cache_Inv_Core1.doj: ../src/Addr_based_Cache_Inv_Core1.c
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cdefSC573.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cdef215xx_core.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdint.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/yvals.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/def215xx_core.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/defSC573.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC57x.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/defSC57x_id_macros.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC5xx_legacy.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC57x_cdef.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/processor_include.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/SC573.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/adi_core.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cache.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdbool.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/builtins.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/builtins_support.h
src/Addr_based_Cache_Inv_Core1.doj: ../system/adi_initialize.h
src/Addr_based_Cache_Inv_Core1.doj: ../src/Addr_based_Cache_Inv_Core1.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cycle_count.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/xcycle_count.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cycle_count_21xxx.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/limits.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdio.h
src/Addr_based_Cache_Inv_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdio_21xxx.h
