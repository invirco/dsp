.section .executable_name;
.byte _executable_name.[] = 'Example4_Core1.dxe',0;

