/*****************************************************************************
 * DMA_Core_Coherency_Core2.h
 *****************************************************************************/

#ifndef __DMA_CORE_COHERENCY_CORE2_H__
#define __DMA_CORE_COHERENCY_CORE2_H__

/* Add your custom header content here */

#endif /* __DMA_CORE_COHERENCY_CORE2_H__ */
