.section .executable_name;
.byte _executable_name.[] = 'Example7_Core2.dxe',0;

