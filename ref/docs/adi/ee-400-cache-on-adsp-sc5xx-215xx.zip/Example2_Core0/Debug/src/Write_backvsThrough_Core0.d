src/Write_backvsThrough_Core0.o: ../src/Write_backvsThrough_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example2_Core0\system/adi_initialize.h \
 ../src/Write_backvsThrough_Core0.h

D:\Work\AppNote_Examplesfinal\Example2_Core0\system/adi_initialize.h:

../src/Write_backvsThrough_Core0.h:
