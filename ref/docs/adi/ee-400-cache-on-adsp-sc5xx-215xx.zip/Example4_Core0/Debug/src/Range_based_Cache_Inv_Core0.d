src/Range_based_Cache_Inv_Core0.o: ../src/Range_based_Cache_Inv_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example4_Core0\system/adi_initialize.h \
 ../src/Range_based_Cache_Inv_Core0.h

D:\Work\AppNote_Examplesfinal\Example4_Core0\system/adi_initialize.h:

../src/Range_based_Cache_Inv_Core0.h:
