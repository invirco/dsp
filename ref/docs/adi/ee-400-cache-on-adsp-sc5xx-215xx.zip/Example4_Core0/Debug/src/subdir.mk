################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Range_based_Cache_Inv_Core0.c 

SRC_OBJS += \
./src/Range_based_Cache_Inv_Core0.o 

C_DEPS += \
./src/Range_based_Cache_Inv_Core0.d 


# Each subdirectory must supply rules for building sources it contributes
src/Range_based_Cache_Inv_Core0.o: ../src/Range_based_Cache_Inv_Core0.c
	@echo 'Building file: $<'
	@echo 'Invoking: CrossCore ARM Bare Metal C Compiler'
	arm-none-eabi-gcc -g -gdwarf-2 -ffunction-sections -fdata-sections -DCORE0 -D_DEBUG -DADI_MCAPI -I"D:\Work\AppNote_Examplesfinal\Example4_Core0\system" -Wall -c -mproc=ADSP-SC573 -msi-revision=0.0 -MMD -MP -MF"src/Range_based_Cache_Inv_Core0.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


