/*****************************************************************************
 * Range_based_Cache_Inv_Core0.h
 *****************************************************************************/

#ifndef __RANGE_BASED_CACHE_INV_CORE0_H__
#define __RANGE_BASED_CACHE_INV_CORE0_H__

/* Add your custom header content here */

#endif /* __RANGE_BASED_CACHE_INV_CORE0_H__ */
