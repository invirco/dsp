.section .executable_name;
.byte _executable_name.[] = 'Example7_Core1.dxe',0;

