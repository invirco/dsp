/*****************************************************************************
 * DMA_Core_Coherency_Core1.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "DMA_Core_Coherency_Core1.h"
#include <cycle_count.h>
#include <sys/cache.h>
#include <stdio.h>

int pass_count = 0;
int err_count,err_count1,err_count2 = 0;

#define SIZE 16384 //(16KB)

#pragma section("seg_l1_block0")
uint8_t Check_Buffer[SIZE]; //Make sure it is in Internal memory


/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();
	
	int i;

	cycle_t start_count1,final_count1,start_count2,final_count2,start_count3,final_count3;

	//Cache is disabled in system.svc and the LDF is modified accordingly.
	//L2 Accesses with Cache disabled

		uint8_t * pL2_Buf1;
		pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			START_CYCLE_COUNT(start_count1);

			// Core accesses update the value in L2
			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xBE;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xAD;
				pL2_Buf1++;
			}

			// MDMA Write of the updated buffer from L2 to L1

			MDMA0_Write((uint8_t *)L2_START_ADDRES1,(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE);
			while(DMA_Completed == 0);
			DMA_Completed = 0;

			STOP_CYCLE_COUNT(final_count1,start_count1);

			//Compare the contents of Check buffer with the expected value
					for(i=0;i<SIZE;i++)
					{
						if(Check_Buffer[i] == 0xAD)
						{
							pass_count++;
						}
						else
							err_count++;
					}

					if(pass_count != (SIZE))
					{
						printf("Error \n");
						return 0;
					}

					pass_count = 0;
					err_count=0;

	printf(" Cycles taken for Cache disabled case (DMA and Core data coherency) =%d core clock cycles \n",final_count1);

	return 0;
}

