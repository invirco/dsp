
The examples Example 6 and Example 7 explore two different methods to maintain coherency
between DMA and core and the performance impact in each case.

DMA is not cached. When data in memory is updated by DMA, the target if cached will not see the change 
and provide stale copies to the application. Hence, the two methods we discussed in appnote to address 
this incoherency are
a) Disable cache
b) Flush cache to update memory before DMA.

In this example, we explore the performance of the case when Cache is disabled.

The code works as follows:

1. Cache is disabled in system.svc and the LDF is modified accordingly.
2. Core accesses update the memory contents in L2
3. DMA will transfer the updated buffer from L2 to L1.

The code measures the time taken for the steps mentioned above.

