.section .executable_name;
.byte _executable_name.[] = 'Example1_Core2.dxe',0;

