/*****************************************************************************
 * Way_Lock_Core2.h
 *****************************************************************************/

#ifndef __WAY_LOCK_CORE2_H__
#define __WAY_LOCK_CORE2_H__

/* Add your custom header content here */

#endif /* __WAY_LOCK_CORE2_H__ */
