/*****************************************************************************
 * DMA_Core_Coherency_Core0.h
 *****************************************************************************/

#ifndef __DMA_CORE_COHERENCY_CORE0_H__
#define __DMA_CORE_COHERENCY_CORE0_H__

/* Add your custom header content here */

#endif /* __DMA_CORE_COHERENCY_CORE0_H__ */
