src/DMA_Core_Coherency_Core0.o: ../src/DMA_Core_Coherency_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example7_Core0\system/adi_initialize.h \
 ../src/DMA_Core_Coherency_Core0.h

D:\Work\AppNote_Examplesfinal\Example7_Core0\system/adi_initialize.h:

../src/DMA_Core_Coherency_Core0.h:
