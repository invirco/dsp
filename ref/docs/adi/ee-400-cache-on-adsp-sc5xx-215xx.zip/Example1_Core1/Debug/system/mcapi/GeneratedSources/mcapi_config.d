system/mcapi/GeneratedSources/mcapi_config.doj: ../system/mcapi/GeneratedSources/mcapi_config.c
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/services/mcapi/mcapi.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stddef.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdint.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/yvals.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/services/mcapi/mca.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdlib.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdlib_21xxx.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/builtins.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/builtins_support.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/builtins.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/builtins_support.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/adi_types.h
system/mcapi/GeneratedSources/mcapi_config.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdbool.h
