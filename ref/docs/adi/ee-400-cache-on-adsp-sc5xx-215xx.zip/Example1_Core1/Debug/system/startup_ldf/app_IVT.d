system/startup_ldf/app_IVT.doj: ../system/startup_ldf/app_IVT.s
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/adi_osal.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/adi_osal_arch.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/defSC589.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/interrupt.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP-SC58x.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC5xx_legacy.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/anomaly_macros_rtl.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/def215xx_core.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/defSC58x_id_macros.h
system/startup_ldf/app_IVT.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/fatal_error_code.h
