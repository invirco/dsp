src/Cache_WayLock_Core1.doj: ../src/Cache_WayLock_Core1.c
src/Cache_WayLock_Core1.doj: ../src/Cache_WayLock_Core1.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdint.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/yvals.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdio.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdio_21xxx.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cdefSC589.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cdef215xx_core.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/def215xx_core.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/defSC589.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP-SC58x.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/defSC58x_id_macros.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC5xx_legacy.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/ADSP_SC58x_cdef.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/processor_include.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/SC589.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/platform_include.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/adi_core.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/platform.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/cache.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/stdbool.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/builtins.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/sys/builtins_support.h
src/Cache_WayLock_Core1.doj: ../system/adi_initialize.h
src/Cache_WayLock_Core1.doj: ../src/SHARC_Cache.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cycle_count.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/xcycle_count.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/cycle_count_21xxx.h
src/Cache_WayLock_Core1.doj: C:/Analog\ Devices/CrossCore\ Embedded\ Studio\ 2.5.0/SHARC/include/limits.h
