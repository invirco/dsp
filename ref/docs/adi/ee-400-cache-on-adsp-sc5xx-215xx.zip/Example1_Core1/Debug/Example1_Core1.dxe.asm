.section .executable_name;
.byte _executable_name.[] = 'Example1_Core1.dxe',0;

