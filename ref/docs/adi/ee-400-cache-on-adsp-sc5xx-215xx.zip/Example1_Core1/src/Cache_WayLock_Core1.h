/*****************************************************************************
 * Test5_Dcache_WayLock_Core1.h
 *****************************************************************************/

#ifndef __TEST5_DCACHE_WAYLOCK_CORE1_H__
#define __TEST5_DCACHE_WAYLOCK_CORE1_H__
#include <stdint.h>
#include <stdio.h>
#include <cdefSC589.h>
#define L2_START_ADDRES1 0x200B0000
#define L2_START_ADDRES2 0x200B4000

int pass_count = 0;
#define SIZE 16384 //(16KB)
uint8_t Check_Buffer[SIZE];//Ensure the buffer is in Internal memory

volatile int DMA_Completed = 0;
void MDMA0_Write(uint8_t * pReadAddress, uint8_t * pWriteAddress, uint32_t iXCount);
void MDMA_Completion_ISR(void);

void MDMA0_Write(uint8_t * pReadAddress, uint8_t * pWriteAddress, uint32_t iXCount)
{
	adi_int_InstallHandler(INTR_SYS_MDMA0_DST,MDMA_Completion_ISR,0,true);


	//Configure MDMA0 Source and Destination channels as secure masters
	*pREG_SPU0_SECUREP88 =0x3;
	*pREG_SPU0_SECUREP89 =0x3;
    // MDMA0 uses DMA channel 8 and 9 on Griffin
    *pREG_DMA8_CFG = 0;
    *pREG_DMA9_CFG = 0;

    *pREG_DMA8_ADDRSTART = (uint32_t *)pReadAddress;		//Initialize start address
    *pREG_DMA8_XCNT      = iXCount;			//Initialize X count
    *pREG_DMA8_XMOD	  = 1;			//Initialize DMA X modifier
    *pREG_DMA8_YCNT	  = 0;			//Initialize Y count
    *pREG_DMA8_YMOD	  = 0;			//Initialize DMA Y modifier

    *pREG_DMA9_ADDRSTART = (uint32_t *)pWriteAddress;		//Initialize start address
    *pREG_DMA9_XCNT	  = iXCount;			//Initialize DMA X count
    *pREG_DMA9_XMOD	  = 1;			//Initialize DMA X modifier
    *pREG_DMA9_YCNT	  = 0;			//Initialize DMA Y count
    *pREG_DMA9_YMOD	  = 0;			//Initialize DMA Y modifier

    *pREG_DMA9_CFG 	  = ENUM_DMA_CFG_EN |  ENUM_DMA_CFG_PSIZE01 |ENUM_DMA_CFG_MSIZE01 |ENUM_DMA_CFG_WRITE | ENUM_DMA_CFG_XCNT_INT;		//Initialize DMA config register
    *pREG_DMA8_CFG    = ENUM_DMA_CFG_EN | ENUM_DMA_CFG_PSIZE01 |ENUM_DMA_CFG_MSIZE01;//Initialize DMA config register

}

void MDMA_Completion_ISR(void)
{
	*pREG_DMA9_STAT |= 0x1;
	DMA_Completed = 1;
}


#endif /* __TEST5_DCACHE_WAYLOCK_CORE1_H__ */
