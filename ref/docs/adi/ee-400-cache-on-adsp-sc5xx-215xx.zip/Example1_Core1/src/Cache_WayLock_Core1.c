/*****************************************************************************
 * Cache_WayLock_Core1.c
 *****************************************************************************/

#include "Cache_WayLock_Core1.h"

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "SHARC_Cache.h"
#include <cycle_count.h>
char __argv_string[] = "";


int main(int argc, char *argv[])
{
	int i;
	RESULT outcome;
	cycle_t start_count1,final_count1,start_count2,final_count2;

	adi_initComponents();

	Read_Cache_Configuration();

	//Cache is enabled in system.svc for configuration:IC 16KB, DM 16KB, PM 16KB and the LDF is generated accordingly.
	//L2 Accesses with Cache enabled and fill the entire cache (Both the ways)

	uint8_t * pL2_Buf1;
	pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

	for(i=0;i<SIZE;i++)
	{
		*pL2_Buf1 = 0xAB;
		pL2_Buf1++;
	}

	//Lock Way 0
	outcome = Cache_Full_WayLock(DM,WAY0);

	if(outcome == SUCCESS)
		DB_print("Cache_Lock successful\n");
		else
			DB_print("Cache_Lock failed\n");

	Read_Cache_Configuration();

	//Try to replace data in way0 by accessing another range having the tag equal to that of way0(for SIZE/2)
	pL2_Buf1 = (uint8_t *)L2_START_ADDRES2;

	for(i=0;i<SIZE/2;i++)
	{
		*pL2_Buf1 = 0xCD;
		pL2_Buf1++;
	}

	// As Way0 is locked and data in cache can't be replaced, addresses from 0x200B0000 to 0x200B1fff should contain zeroes
	MDMA0_Write((uint8_t *)L2_START_ADDRES1,(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE/2);
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value
	for(i=0;i<SIZE/2;i++)
	{
		if(Check_Buffer[i] != 0xAB)
		{
			pass_count++;
		}
		else
			DB_print("Error : Way0 Lock failed\n");
	}

	if(pass_count != (SIZE/2))
	{
		printf("Error : Way0 Lock failed\n");
		return 0;
	}
	pass_count = 0;

	// Address from 0x200B2000 to 0x200B3fff should be written back as it has been replaced during the above access
	MDMA0_Write((uint8_t *)(L2_START_ADDRES1+(SIZE/2)),(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE/2);
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value
	for(i=0;i<SIZE/2;i++)
	{
		if(Check_Buffer[i] == 0xAB)
		{
			pass_count++;
		}
		else
			DB_print("Error : Way1 also locked - Failure\n");
	}
	if(pass_count != SIZE/2)
	{
		printf("Error : Way1 also locked - Failure\n");
		return 0;
	}



	printf("\n\nTest Passed : Way0 cache lock successful\n");

	return 0;
}

