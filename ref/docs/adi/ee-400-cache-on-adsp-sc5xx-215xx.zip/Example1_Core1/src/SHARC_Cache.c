/*
 * SHARC_Cache.c
 *
 *  Created on: Feb 3, 2016
 *      Author: MNataraj
 */

#include "SHARC_Cache.h"
#include <sys/platform.h>


void Read_Cache_Configuration(void)
{
	volatile uint32_t Cache_Config,Cache_Config2,range_start,range_end;

	DB_print("/*---------------------------------------------------*/\n");

	Cache_Config = *pREG_SHL1C0_CFG;
	DB_print("CFG = 0x%X\n",Cache_Config);

	Cache_Config2 = *pREG_SHL1C0_CFG2;
	DB_print("CFG2 = 0x%X\n",Cache_Config2);

	range_start = *pREG_SHL1C0_RANGE_START0;
	DB_print("RANGE_START0 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END0;
	DB_print("RANGE_END0 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START1;
	DB_print("RANGE_START1 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END1;
	DB_print("RANGE_END1 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START2;
	DB_print("RANGE_START2 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END2;
	DB_print("RANGE_END2 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START3;
	DB_print("RANGE_START3 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END3;
	DB_print("RANGE_END3 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START4;
	DB_print("RANGE_START4 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END4;
	DB_print("RANGE_END4 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START5;
	DB_print("RANGE_START5 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END5;
	DB_print("RANGE_END5 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START6;
	DB_print("RANGE_START6 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END6;
	DB_print("RANGE_END6 = 0x%X\n",range_end);

	range_start = *pREG_SHL1C0_RANGE_START7;
	DB_print("RANGE_START7 = 0x%X\n",range_start);
	range_end = *pREG_SHL1C0_RANGE_END7;
	DB_print("RANGE_END7 = 0x%X\n",range_end);

	DB_print("/*---------------------------------------------------*/\n\n");
}

RESULT Cache_Init (CACHE ic,CACHE_SIZE a,CACHE dmc,CACHE_SIZE b,CACHE pmc,CACHE_SIZE c)
{
	/* Cache Disabled */
	if(a == Disabled && b == Disabled && c == Disabled){
		*pREG_SHL1C0_CFG = 0;
		adi_rtl_wait_for_cache_latency(); // 11 cycle latency
		return SUCCESS;
	}

	/* Only I cache enabled */
	else if(a != Disabled && b == Disabled && c == Disabled){
		*pREG_SHL1C0_CFG = ((1 << BITP_SHL1C_CFG_ICAINV)|(1 << BITP_SHL1C_CFG_ICAEN) | (a << BITP_SHL1C_CFG_ICASIZ0));
		adi_rtl_wait_for_cache_latency(); // 11 cycle latency
		return SUCCESS;
	}

	/* All cache enabled */
	else if(a != Disabled && b != Disabled && c != Disabled){
		*pREG_SHL1C0_CFG = ((1 << BITP_SHL1C_CFG_ICAINV)|(1 << BITP_SHL1C_CFG_ICAEN) | (a << BITP_SHL1C_CFG_ICASIZ0)|
				(1 << BITP_SHL1C_CFG_DMCAINV)|(1 << BITP_SHL1C_CFG_DMCAEN) | (b << BITP_SHL1C_CFG_DMCASIZ0)|
				(1 << BITP_SHL1C_CFG_PMCAINV)|(1 << BITP_SHL1C_CFG_PMCAEN) | (c << BITP_SHL1C_CFG_PMCASIZ0));
		adi_rtl_wait_for_cache_latency(); // 11 cycle latency
		return SUCCESS;
	}

	else
		return FAILURE;
}

RESULT Cache_Full_WayLock(CACHE type, CACHE_WAY ways)
{
	switch(type){
	case IC:
		if(ways)
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_ICALCK1);
		else
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_ICALCK0);
		break;

	case DM:
		if(ways)
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_DMCALCK1);
		else
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_DMCALCK0);
		break;

	case PM:
		if(ways)
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_PMCALCK1);
		else
			*pREG_SHL1C0_CFG |= (1 << BITP_SHL1C_CFG_PMCALCK0);
		break;

	default:
		printf("Invalid cache type\n");
		return FAILURE;
	}
	adi_rtl_wait_for_cache_latency(); // 11 cycle latency

	return SUCCESS;

}

void dummy(char *a,...){}
