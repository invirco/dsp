/*
 * SHARC_Cache.h
 *
 *  Created on: Feb 3, 2016
 *      Author: MNataraj
 */

#ifndef SHARC_CACHE_H_
#define SHARC_CACHE_H_

#define DB_print dummy
	void dummy(char *a,...);

#include <stdio.h>
#include <stdint.h>

typedef enum
{
	IC,
	DM,
	PM
}CACHE;

typedef enum
{
	WAY0,
	WAY1
}CACHE_WAY;


typedef enum
{
	Size_16KB,
	Size_32KB,
	Size_64KB,
	Size_128KB,
	Disabled
}CACHE_SIZE;

typedef enum
{
	SUCCESS,
	FAILURE
}RESULT;

#define BAUD_115200_30MHZ  260
#define BAUD_115200_100MHZ 977
#define BAUD_9600_112MHZ 11719
#define BAUD_57600_112MHZ 1953

//Range of addresses covering one way of 16KB cache
#define L2_start1 	(uint8_t *)0x20020000
#define L2_end1		(uint8_t *)0x20021fff

//Range of addresses covering one way of 16KB cache
#define L2_start2 	(uint8_t *)0x20022000
#define L2_end2		(uint8_t *)0x20023fff

//Range of addresses covering one way of 16KB cache
#define L2_start3 	(uint8_t *)0x20024000
#define L2_end3		(uint8_t *)0x20025fff

//Range of addresses covering one way of 16KB cache
#define L2_start4 	(uint8_t *)0x20026000
#define L2_end4 	(uint8_t *)0x20027fff

#define cache16KB_size  (uint32_t)16384 //Bytes
#define cache32KB_size  (uint32_t)32768 //Bytes
#define cache64KB_size  (uint32_t)65536 //Bytes
#define cache128KB_size (uint32_t)131072 //Bytes

#define DMcache_16 	(uint8_t *)0x2dc000
#define DMcache_32 	(uint8_t *)0x2d8000
#define DMcache_64 	(uint8_t *)0x2d0000
#define DMcache_128 (uint8_t *)0x2c0000

#define PMcache_16 	(uint8_t *)0x30c000
#define PMcache_32 	(uint8_t *)0x308000
#define PMcache_64 	(uint8_t *)0x300000

#define ICcache_16 	(uint8_t *)0x38c000
#define ICcache_32 	(uint8_t *)0x388000
#define ICcache_64 	(uint8_t *)0x380000

void Uart_Init(void);
void Write_Byte(uint8_t * start_add, uint8_t * end_address, uint8_t pattern);
void Read_Byte(uint8_t * start_add, uint8_t * end_address, uint8_t pattern);
void ThrowData_UART(uint8_t * array, uint32_t size);
void Dump_CacheData(CACHE Type,CACHE_SIZE size);
void Dump_valid(CACHE Type,CACHE_SIZE size);
void Dump_CacheTag(CACHE Type,CACHE_SIZE size);
void Dump_CacheLD(CACHE Type,CACHE_SIZE size);
void Dump_Cache(CACHE Type,CACHE_SIZE size);

void Read_Cache_Configuration(void);
RESULT Cache_Init (CACHE ic,CACHE_SIZE a,CACHE dmc,CACHE_SIZE b,CACHE pmc,CACHE_SIZE c);
RESULT Cache_Full_WayLock(CACHE type, CACHE_WAY ways);
#endif /* SHARC_CACHE_H_ */
