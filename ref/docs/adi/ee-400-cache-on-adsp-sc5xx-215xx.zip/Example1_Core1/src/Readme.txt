
This example demonstrates the cache-way locking feature. 

The code works as follows.

1. Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.
2. L2 Accesses with Cache enabled and fill the entire cache (Both the ways)
3. Cache way is locked and the data in cache is tried to be replaced. 
4. Contents in locked way are not replaced. The final values are compared for the expected output.

NOTE-

Please ensure that you don't place breakpoints or add any additional printf statements apart from 
the used while running the code as these result in Cache flush and could result in errors.
