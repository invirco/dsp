

This code shows the configuration of range registers to set a write-through range and shows a relative performance
comparison of write-back vs write-through acesses

The code works as follows.

1. Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.
2. L2 Accesses with Cache enabled and fill the entire cache (Both the ways)
3. The contents in Cache are modified. L2 will not contain updated values of buffer till it is written back.
4. MDMA doesn't modify the Cache contents. Using MDMA to check the L2 contents and not modify the cache content 
and compare it with the expected value.
5. Accessing L2 through the write-through range and modifying the contents.
6. Measuring the cycles taken for Write-back and Write-through cases.


NOTE-

Please ensure that you don't place breakpoints or add any additional printf statements apart from 
the used while running the code as these result in Cache flush and could result in errors.

For through accesses, the access request is forwarded to external memory only if it is found to be un-cached.
Through accesses are launched after checking the conditions listed in section "Write-through accesses" of
SHARC+ Core Programming Reference Manual and take more cycles than un-cached accesses.