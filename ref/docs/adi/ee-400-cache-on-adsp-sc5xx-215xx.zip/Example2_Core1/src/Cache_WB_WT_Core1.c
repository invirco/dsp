/*****************************************************************************
 * Cache_WB_WT_Core1.c
 *****************************************************************************/

#include "Cache_WB_WT_Core1.h"
#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "SHARC_Cache.h"
#include <cycle_count.h>
#include <sys/cache.h>
#include <sharc_rom.h>

char __argv_string[] = "";

int main(int argc, char *argv[])
{
	int i;
	adiCacheStatus outcome;
	cycle_t start_count1,start_count2,start_count3,start_count4;
	cycle_t final_count1,final_count2,final_count3,final_count4;

	adi_initComponents();

	outcome = adi_cache_set_range((void*)L2_START_ADDRES2,(void*) L2_START_ADDRES3, adi_cache_rr4, adi_cache_wt_range);

	if(outcome == adi_cache_success)
		DB_print("Range registers configuration successful\n");
		else
			DB_print("Range registers configuration failed\n");

	Read_Cache_Configuration();

	//Cache is enabled in system.svc for configuration:IC 16KB, DM 16KB, PM 16KB and the LDF is generated accordingly.
	//L2 Accesses with Cache enabled and fill the entire cache (Both the ways)
		uint8_t * pL2_Buf1;
		pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

		START_CYCLE_COUNT(start_count1);
		for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xAB;
				pL2_Buf1++;
			}
		STOP_CYCLE_COUNT(final_count1,start_count1);

	//The contents in Cache are modified. L2 will not contain updated values of buffer till it is written back
		pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

		START_CYCLE_COUNT(start_count2);
		for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xCD;
				pL2_Buf1++;
			}
		STOP_CYCLE_COUNT(final_count2,start_count2);

	//Using MDMA to	check the L2 contents and not modify the cache content
		MDMA0_Write((uint8_t *)L2_START_ADDRES1,(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE);
		while(DMA_Completed == 0);
		DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value
		for(i=0;i<SIZE;i++)
		{
			if(Check_Buffer[i] == 0xCD)
			{
				DB_print("Error : Write-back failed\n");
			}
			else
				pass_count++;
		}

			if(pass_count != (SIZE))
			{
				printf("Error : Write-back failed\n");
				return 0;
			}

		pass_count = 0;

	Read_Cache_Configuration();
	//L2 accesses in the Write through range
	pL2_Buf1 = (uint8_t *)L2_START_ADDRES2;

	START_CYCLE_COUNT(start_count3);
	for(i=0;i<SIZE;i++)
		{
			*pL2_Buf1 = 0xEF;
			 pL2_Buf1++;
			// asm("sync;");
		}
	STOP_CYCLE_COUNT(final_count3,start_count3);

	pL2_Buf1 = (uint8_t *)L2_START_ADDRES2;

	START_CYCLE_COUNT(start_count4);
	for(i=0;i<SIZE;i++)
		{
			*pL2_Buf1 = 0xAD;
			 pL2_Buf1++;
			 //asm("sync;");
		}
	STOP_CYCLE_COUNT(final_count4,start_count4);


	// Address from 0x200B4000 to 0x200B7fff should be written to the external memory
	MDMA0_Write((uint8_t *)(L2_START_ADDRES2),(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE);
	while(DMA_Completed == 0);
	DMA_Completed = 0;

	//Compare the contents of Check buffer with the expected value
	for(i=0;i<SIZE;i++)
	{
		if(Check_Buffer[i] == 0xAD)
		{
			pass_count++;
		}
		else
			DB_print("Error : Write-through Failure\n");
	}
	if(pass_count != SIZE)
	{
		printf("Error : Write-through Failure\n");
		return 0;
	}

	printf("\nL2 access with cache Iteration 1 : %d\n",final_count1);
	printf("\nL2 access with cache Iteration 2 : %d\n",final_count2);
	printf("\nWrite-through L2 access 1st iteration : %d\n",final_count3);
	printf("\nWrite-through L2 access 2nd Iteration : %d\n",final_count4);


	return 0;
}

