.section .executable_name;
.byte _executable_name.[] = 'Example2_Core1.dxe',0;

