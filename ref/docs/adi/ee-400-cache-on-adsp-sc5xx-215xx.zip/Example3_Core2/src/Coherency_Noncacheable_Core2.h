/*****************************************************************************
 * Coherency_Noncacheable_Core2.h
 *****************************************************************************/

#ifndef __COHERENCY_NONCACHEABLE_CORE2_H__
#define __COHERENCY_NONCACHEABLE_CORE2_H__

/* Add your custom header content here */

#endif /* __COHERENCY_NONCACHEABLE_CORE2_H__ */
