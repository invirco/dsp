################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Coherency_Noncacheable_Core2.c 

SRC_OBJS += \
./src/Coherency_Noncacheable_Core2.doj 

C_DEPS += \
./src/Coherency_Noncacheable_Core2.d 


# Each subdirectory must supply rules for building sources it contributes
src/Coherency_Noncacheable_Core2.doj: ../src/Coherency_Noncacheable_Core2.c
	@echo 'Building file: $<'
	@echo 'Invoking: CrossCore SHARC C/C++ Compiler'
	cc21k.exe -c -file-attr ProjectName="Example3_Core2" -proc ADSP-SC589 -flags-compiler --no_wrap_diagnostics -si-revision 1.0 -g -DCORE2 -D_DEBUG -DADI_MCAPI -I"D:\Work\AppNote_Examplesfinal\Example3_Core2\system" -structs-do-not-overlap -no-const-strings -no-multiline -warn-protos -double-size-32 -char-size-8 -swc -gnu-style-dependencies -MD -Mo "src/Coherency_Noncacheable_Core2.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


