.section .executable_name;
.byte _executable_name.[] = 'Example3_Core2.dxe',0;

