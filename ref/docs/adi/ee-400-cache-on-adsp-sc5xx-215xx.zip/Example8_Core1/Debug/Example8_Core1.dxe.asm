.section .executable_name;
.byte _executable_name.[] = 'Example8_Core1.dxe',0;

