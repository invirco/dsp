################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Capacity_Miss_Cache_Core1.c 

SRC_OBJS += \
./src/Capacity_Miss_Cache_Core1.doj 

C_DEPS += \
./src/Capacity_Miss_Cache_Core1.d 


# Each subdirectory must supply rules for building sources it contributes
src/Capacity_Miss_Cache_Core1.doj: ../src/Capacity_Miss_Cache_Core1.c
	@echo 'Building file: $<'
	@echo 'Invoking: CrossCore SHARC C/C++ Compiler'
	cc21k.exe -c -file-attr ProjectName="Example8_Core1" -proc ADSP-SC589 -flags-compiler --no_wrap_diagnostics -si-revision 1.0 -O -Ov100 -g -DCORE1 -DDO_CYCLE_COUNTS -D_DEBUG -DADI_MCAPI -I"D:\Work\AppNote_Examplesfinal\Example8_Core1\system" -structs-do-not-overlap -no-const-strings -no-multiline -warn-protos -double-size-32 -char-size-8 -swc -compatible-pm-dm -gnu-style-dependencies -MD -Mo "src/Capacity_Miss_Cache_Core1.d" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


