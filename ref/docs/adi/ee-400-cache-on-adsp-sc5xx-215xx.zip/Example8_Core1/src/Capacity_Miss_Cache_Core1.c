/*****************************************************************************
 * Capacity_Miss_Cache_Core1.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include "Capacity_Miss_Cache_Core1.h"
#include <cycle_count.h>
#include <sys/cache.h>
#include <stdio.h>

int pass_count = 0;
int err_count,err_count1,err_count2 = 0;

#pragma section("seg_l1_block0")
uint8_t Check_Buffer[SIZE]; //Make sure it is in Internal memory


/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();
	
	int i;

	cycle_t start_count1,final_count1,start_count2,final_count2,start_count3,final_count3;


	//Cache is enabled for 32KB DM, PM and I Cache
	//L2 Accesses with Cache ON and fill the entire cache (Both the ways) . All the lines will be valid

		uint8_t * pL2_Buf1;

		pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;



#ifdef CapacityMiss

	/* Begin adding your custom code here */
			START_CYCLE_COUNT(start_count1);

			// Core accesses update the value in cache. Frequent accesses to the full buffer accesses
			//lead to frequent cache trashing
			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xBE;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0x7D;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = (*pL2_Buf1)*2;
				 pL2_Buf1++;

			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = ((*pL2_Buf1)>>1);
				pL2_Buf1++;

			}

			STOP_CYCLE_COUNT(final_count1,start_count1);

#endif

#ifdef Avoid_CapacityMiss

			uint8_t *  pL2_Buf12;

	/* Begin adding your custom code here */
			START_CYCLE_COUNT(start_count1);

			// Avoid cache trashing by splitting into two smaller buffers
			for(i=0;i<SIZE_32K;i++)
			{
				*pL2_Buf1 = 0xBE;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE_32K;i++)
			{
				*pL2_Buf1 = 0x7D;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE_32K;i++)
			{
				*pL2_Buf1 = (*pL2_Buf1)*2;
				 pL2_Buf1++;

			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE_32K;i++)
			{
				*pL2_Buf1 = ((*pL2_Buf1)>>1);
				pL2_Buf1++;

			}

			pL2_Buf12 = (uint8_t *)L2_START_ADDRES1+SIZE_32K;

			for(i=0;i<SIZE_8K;i++)
			{
				*pL2_Buf12 = 0xBE;
				pL2_Buf12++;
			}

			pL2_Buf12 = (uint8_t *)L2_START_ADDRES1+SIZE_32K;

			for(i=0;i<SIZE_8K;i++)
			{
				*pL2_Buf12 = 0x7D;
				pL2_Buf12++;
			}

			pL2_Buf12 = (uint8_t *)L2_START_ADDRES1+SIZE_32K;

			for(i=0;i<SIZE_8K;i++)
			{
				*pL2_Buf12 = (*pL2_Buf12)*2;
				pL2_Buf12++;

			}

			pL2_Buf12 = (uint8_t *)L2_START_ADDRES1+SIZE_32K;

			for(i=0;i<SIZE_8K;i++)
			{
				*pL2_Buf12 = ((*pL2_Buf12)>>1);
				pL2_Buf12++;

			}


			STOP_CYCLE_COUNT(final_count1,start_count1);

#endif





	printf(" Cycles taken =%d core clock cycles \n",final_count1);

	return 0;
}

