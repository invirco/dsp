
This example talks about Capacity miss in cache 

a)By having buffers larger than the cache size could lead to frequent cache trashing.
b) Avoid cache trashing by defing buffers smaller than or equal to the configured cache size


