src/Coherency_Noncacheable_Core0.o: ../src/Coherency_Noncacheable_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example3_Core0\system/adi_initialize.h \
 ../src/Coherency_Noncacheable_Core0.h

D:\Work\AppNote_Examplesfinal\Example3_Core0\system/adi_initialize.h:

../src/Coherency_Noncacheable_Core0.h:
