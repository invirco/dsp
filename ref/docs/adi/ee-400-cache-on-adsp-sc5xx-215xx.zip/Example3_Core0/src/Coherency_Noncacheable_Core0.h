/*****************************************************************************
 * Coherency_Noncacheable_Core0.h
 *****************************************************************************/

#ifndef __COHERENCY_NONCACHEABLE_CORE0_H__
#define __COHERENCY_NONCACHEABLE_CORE0_H__

/* Add your custom header content here */

#endif /* __COHERENCY_NONCACHEABLE_CORE0_H__ */
