.section .executable_name;
.byte _executable_name.[] = 'Example4_Core2.dxe',0;

