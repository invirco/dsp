/*****************************************************************************
 * Range_based_Cache_Inv_Core2.h
 *****************************************************************************/

#ifndef __RANGE_BASED_CACHE_INV_CORE2_H__
#define __RANGE_BASED_CACHE_INV_CORE2_H__

/* Add your custom header content here */

#endif /* __RANGE_BASED_CACHE_INV_CORE2_H__ */
