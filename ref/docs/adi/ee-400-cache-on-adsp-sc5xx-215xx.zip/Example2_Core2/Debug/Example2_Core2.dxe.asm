.section .executable_name;
.byte _executable_name.[] = 'Example2_Core2.dxe',0;

