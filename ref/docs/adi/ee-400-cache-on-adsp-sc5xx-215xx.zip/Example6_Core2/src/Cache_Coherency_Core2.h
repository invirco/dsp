/*****************************************************************************
 * Cache_Coherency_Core2.h
 *****************************************************************************/

#ifndef __CACHE_COHERENCY_CORE2_H__
#define __CACHE_COHERENCY_CORE2_H__

/* Add your custom header content here */

#endif /* __CACHE_COHERENCY_CORE2_H__ */
