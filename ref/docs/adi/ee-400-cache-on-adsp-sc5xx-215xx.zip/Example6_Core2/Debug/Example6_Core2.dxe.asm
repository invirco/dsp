.section .executable_name;
.byte _executable_name.[] = 'Example6_Core2.dxe',0;

