.section .executable_name;
.byte _executable_name.[] = 'Example3_Core1.dxe',0;

