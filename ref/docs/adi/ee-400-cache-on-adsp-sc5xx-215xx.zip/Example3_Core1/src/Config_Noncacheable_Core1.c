/*****************************************************************************
 * Coherency_Noncacheable_Core1.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"
#include <cycle_count.h>
#include <sys/cache.h>
#include <stdio.h>
int pass_count = 0;

#include "Config_Noncacheable_Core1.h"
int err_count,err_count1,err_count2 = 0;

char __argv_string[] = "";

#define SIZE 16384 //(16KB)

#pragma section("seg_l1_block0")
uint8_t Check_Buffer[SIZE];//Make sure it is in Internal memory

int main(int argc, char *argv[])
{
	int i;

	adi_initComponents();

	cycle_t start_count1,final_count1,start_count2,final_count2,start_count3,final_count3;

	//Cache is enabled in system.svc with DM 16KB PM 16KB and ICache 16KB and the LDF is modified accordingly.
	//L2 Accesses with Cache ON and fill the entire cache (Both the ways) . All the lines will be valid

	uint8_t * pL2_Buf1;
	pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

	flush_data_buffer(L2_START_ADDRES1, L2_START_ADDRES1+SIZE, ADI_FLUSH_DATA_INV);

	 /* Configuring Range-based registers to set region as non-cacheable region*/

	adi_cache_set_range(L2_START_ADDRES1, L2_START_ADDRES1+SIZE,adi_cache_rr4,adi_cache_noncacheable_range);


			// Core accesses update the value in the non-cacheable address range
			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xBE;
				pL2_Buf1++;
			}

			pL2_Buf1 = (uint8_t *)L2_START_ADDRES1;

			for(i=0;i<SIZE;i++)
			{
				*pL2_Buf1 = 0xAD;
				pL2_Buf1++;
			}

			// MDMA Write of the updated buffer from L2 to L1

			MDMA0_Write((uint8_t *)L2_START_ADDRES1,(uint8_t *)((uint32_t)Check_Buffer|(uint32_t)0x28000000),SIZE);
			while(DMA_Completed == 0);
			DMA_Completed = 0;


			//Compare the contents of Check buffer with the expected value
					for(i=0;i<SIZE;i++)
					{
						if(Check_Buffer[i] == 0xAD)
						{
							pass_count++;
						}
						else
							err_count++;
					}

					if(pass_count != (SIZE))
					{
						printf("Error \n");
						return 0;
					}

					pass_count = 0;
					err_count=0;


			 printf(" Flush data buffer and Range registers configuration example completed \n" );




	return 0;
}

