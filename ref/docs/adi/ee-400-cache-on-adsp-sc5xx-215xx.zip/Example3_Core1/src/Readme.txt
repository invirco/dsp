
This example showcases how to program range registers and also how to use flush_data_buffer for 
flushing the cache based on address range.  

This code works as follows:

The memory address range which is updated through MDMA as set in non-cacheable region in range registers. Core accesses the non-cacheable 
region and updates the buffer which is then accessed by MDMA.


NOTE: Please do not place breakpoints or printf statements in between while running the code. Breakpoints/Printf cause
	Cache flush and will result in incorrect results.