src/Cache_Coherency_Core0.o: ../src/Cache_Coherency_Core0.c \
 D:\Work\AppNote_Examplesfinal\Example6_Core0\system/adi_initialize.h \
 ../src/Cache_Coherency_Core0.h

D:\Work\AppNote_Examplesfinal\Example6_Core0\system/adi_initialize.h:

../src/Cache_Coherency_Core0.h:
