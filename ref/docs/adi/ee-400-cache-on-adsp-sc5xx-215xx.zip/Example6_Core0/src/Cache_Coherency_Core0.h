/*****************************************************************************
 * Cache_Coherency_Core0.h
 *****************************************************************************/

#ifndef __CACHE_COHERENCY_CORE0_H__
#define __CACHE_COHERENCY_CORE0_H__

/* Add your custom header content here */

#endif /* __CACHE_COHERENCY_CORE0_H__ */
