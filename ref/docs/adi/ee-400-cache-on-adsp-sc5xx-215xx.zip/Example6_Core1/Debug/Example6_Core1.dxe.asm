.section .executable_name;
.byte _executable_name.[] = 'Example6_Core1.dxe',0;

