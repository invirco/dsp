
DMA and Core accesses incoherency

The examples Example 6 and Example 7 explore two different methods to maintain coherency
between DMA and core and the performance impact in each case.

DMA is not cached. When data in memory is updated by DMA, the target if cached will not see the change 
and provide stale copies to the application. Hence, the two methods we discussed in appnote to address 
this incoherency are
a) Disable cache
b) Flush cache to update memory before DMA.

This example looks into Case (b)

Cache is enabled. Core accesses buffer in L2 and updates the value of the buffer. This updated copy is available in 
Cache. Cache should be flushed for the updated copy to be available for MDMA. Cache copy must be invalidated before 
MDMA accesses the memory for updated value.
   
NOTE: Please do not place breakpoints or printf statements in between while running the code. Breakpoints/Printf cause
	Cache flush and will result in incorrect results.