/*****************************************************************************
 * AppNote_example_Core1.h
 *****************************************************************************/

#ifndef __APPNOTE_EXAMPLE_CORE1_H__
#define __APPNOTE_EXAMPLE_CORE1_H__

/* Add your custom header content here */
#include <sys/platform.h>
#include <stdint.h>
volatile int DMA_Completed;

#define Case1

#ifndef Case1
	#define Case2
#endif

#define L2_START_ADDRES1 0x200b0000
#define INV_START 0x200b0000
#define INV_END   0x200b1000

void MDMA0_Write(uint8_t * pReadAddress, uint8_t * pWriteAddress, uint32_t iXCount);
void MDMA_Completion_ISR(void);

volatile int DMA_Completed = 0;

void MDMA0_Write(uint8_t * pReadAddress, uint8_t * pWriteAddress, uint32_t iXCount)
{
	adi_int_InstallHandler(INTR_SYS_MDMA0_DST,MDMA_Completion_ISR,0,true);

    // MDMA0 use DMA channel 8 and 9 on Griffin
    *pREG_DMA8_CFG = 0;
    *pREG_DMA9_CFG = 0;

    *pREG_SPU0_SECUREP88 =0x3;
    *pREG_SPU0_SECUREP88 =0x3;

    *pREG_DMA8_ADDRSTART = (uint32_t *)pReadAddress;;		//Initialize start address
    *pREG_DMA8_XCNT      = iXCount;			//Initialize X count
    *pREG_DMA8_XMOD	  = 1;			//Initialize DMA X modifier
    *pREG_DMA8_YCNT	  = 0;			//Initialize Y count
    *pREG_DMA8_YMOD	  = 0;			//Initialize DMA Y modifier

    *pREG_DMA9_ADDRSTART = (uint32_t *)pWriteAddress;		//Initialize start address
    *pREG_DMA9_XCNT	  = iXCount;			//Initialize DMA X count
    *pREG_DMA9_XMOD	  = 1;			//Initialize DMA X modifier
    *pREG_DMA9_YCNT	  = 0;			//Initialize DMA Y count
    *pREG_DMA9_YMOD	  = 0;			//Initialize DMA Y modifier

    *pREG_DMA9_CFG 	  = ENUM_DMA_CFG_EN |  ENUM_DMA_CFG_PSIZE01 |ENUM_DMA_CFG_MSIZE01 |ENUM_DMA_CFG_WRITE | ENUM_DMA_CFG_XCNT_INT;		//Initialize DMA config register
    *pREG_DMA8_CFG    = ENUM_DMA_CFG_EN | ENUM_DMA_CFG_PSIZE01 |ENUM_DMA_CFG_MSIZE01;//Initialize DMA config register

}

void MDMA_Completion_ISR(void)
{
	*pREG_DMA9_STAT |= 0x1;
	DMA_Completed = 1;
}


#endif /* __APPNOTE_EXAMPLE_CORE1_H__ */
