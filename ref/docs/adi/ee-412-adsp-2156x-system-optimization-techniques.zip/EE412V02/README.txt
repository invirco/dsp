*********************************************************************************************************************************


	This directory is associated with Rev 2 of the Application Note


    		ADSP-2156x SHARC+ Processors System Optimization Techniques   (EE-412)  


	that can be found at http://www.analog.com/ee-notes


	Analog Devices, Inc.
	DSP Division
	Three Technology Way
	P.O. Box 9106
	Norwood, MA 02062

	Date Created:    August 12, 2020


*********************************************************************************************************************************

Description of the EE-Note:

	The purpose of this application note is to discuss the processor's key architectural features contributing to the overall system bandwidth,
        as well as various available bandwidth optimization techniques. 


*********************************************************************************************************************************
Code Details: 

DMC_SCB_PRIO		:	This code shows how to make use of the DMC SCB priority feature to prioritize DMC transfers for a specific master(e.g. MDMA).
EMDMA_Throughput	:	This example code can be used to measure EMDMA throughput for different parameters.
MDMA_1DAuto		:	This example code illustrates the difference between the performance of the APIs adi_mdma_Copy1D and adi_mdma_Copy1DAuto for non 32 aligned start address values.
MDMA_BWLimit		:	This code can be used to measure ADSP-2156x Core FIR performance for different filter parameters. 
MDMA_BWMonitor		:	This example code shows how to use adi_mdma_BWLimit API for limiting MDMA bandwidth.
MDMA_Circular_Buffer	:	This example code shows how MDMA can be used in descriptor based mode to emulate circular buffering supported by EMDMA. It also compared the performance between the two approaches for a given use case.
MDMA_Throughput		:	This example code can be used to measure MDMA throughput for different parameters.
MMR_Latency		:	This example code can be used to measure MMR latency for different peripheral registers.
Multiple_DMAs		:	This example code shows how to use different optimization techniques when multiple MDMAs are accessing the same slave (L3) in parallel.

*****************************************************************************************

All code examples have been written and tested with

	ADSP-21569 silicon revision 0.0
	ADSP-21569 EZ-Board revision B
	
    CrossCore Embedded Studio Tools version 2.9.3

*****************************************************************************************

