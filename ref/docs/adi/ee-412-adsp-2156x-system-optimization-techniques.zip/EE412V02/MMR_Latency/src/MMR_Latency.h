/*****************************************************************************
 * ADSP-2156x_MMR_Latency.h
 *****************************************************************************/

#ifndef __ADSP_2156X_MMR_LATENCY_H__
#define __ADSP_2156X_MMR_LATENCY_H__

#include "time.h"

#define TOTAL_REGISTERS 58

/* Add your custom header content here */

#define START_CYCLE_COUNT\
		cycle_start = clock();\

#define TAKE_CYCLE_SNAPSHOT_WRITE\
		cycle_stop = clock();\
		cycles_write=cycle_stop-cycle_start;\
		cycle_start=cycle_stop;

#define TAKE_CYCLE_SNAPSHOT_READ\
		cycle_stop = clock();\
		cycles_read=cycle_stop-cycle_start;\
		cycle_start=cycle_stop;

#define PRINT_CYCLES\
	printf("\n\nRegister Number=%d, Register address=0x%x", i, pRegisterArray[i]);\
	printf("\nWrite Cycles=%d, Read Cycles=%d", cycles_write, cycles_read);

#endif /* __ADSP_2156X_MMR_LATENCY_H__ */
