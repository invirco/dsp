/* This example code shows how to use adi_mdma_BWMonitor API to monitor the MDMA bandwidth.
 * It uses adi_mdma_BWLimit API to limit the MDMA bandwidth to less than the BW programmed with
 * the adi_mdma_BWMonitor API and thus forces the BW monitor count to expire.
 * Test combinations can be varied in "testparam.dat" file.
 */
/*=============  INCLUDES  =============*/
#include "main.h"
/* Managed drivers and/or services include */
#include "../system/adi_initialize.h"

/*=============  LOCAL DEFINES   =============*/
/* When the processor's L1 and/or L2 cache is enabled the receive data buffers must */
/* be aligned on cache line boundaries. If they are not then any data access by the core may        */
/* pull a buffer into the cache while the DMA is operating on the data buffer. Both the core and    */
/* the DMA are masters on the bus. The core will be performing cache operations. The DMA engine will*/
/* not be. So it is important for the application to both align data that will be operated on by the*/
/* DMA and to separate this data from other application data.                                       */
#define DSTALIGN ADI_CACHE_ALIGN_MIN_4
#define SRCALIGN _Pragma("align 32")


/*=============  DATA  =============*/
/* DMA Stream Handle */
static ADI_DMA_STREAM_HANDLE   hMemDmaStream;
/* Source DMA Handle */
static ADI_DMA_CHANNEL_HANDLE  hSrcDmaChannel;
/* Destination DMA Handle */
static ADI_DMA_CHANNEL_HANDLE  hDestDmaChannel;

/* Flag to register Memory DMA copy completion */
static volatile bool bMemCopyInProgress;

/* Flag to register BW monitor expire event */
static volatile bool bBWMonitorExpried = false;

/* Memory to handle DMA Stream */
static uint8_t MemDmaStreamMem[ADI_DMA_STREAM_REQ_MEMORY];

/* Source channel data buffer.
 * Aligned at least to an MSIZE-byte boundary.
 */
#pragma section("seg_l1_block1")
SRCALIGN static uint8_t SrcDataBuf[MAX_MEMCOPY_BUF_SIZE];

/* Destination channel data buffer.
 * Aligned at least to an MSIZE-byte boundary, and to the cache line size.
 */
#pragma section("seg_l1_block2")
DSTALIGN static uint8_t DestDataBuf[ADI_CACHE_ROUND_UP_SIZE(MAX_MEMCOPY_BUF_SIZE, uint8_t)];

/* Holds list of all the test parameters combinations for which the test should run */
#pragma section ("seg_l2")
TEST_PARAM TestParamArray[MAX_TEST_COMBINATIONS]=
{
	#include "testparam.dat"
};

/* To keep track of the total number of failures */
int fail_count=0;

/* To keep track of the failed test combinations */
uint32_t TestFaillog[MAX_TEST_COMBINATIONS];

/* Holds the test suite information*/
TEST_INFO TestInfo =
{
	TestParamArray, 0
};


/*=============  LOCAL FUNCTION DECLARATIONS  =============*/
/* Initializes SPU service */
static ADI_DMA_RESULT SpuInit(void);

/* Prepares data buffers for Memory DMA copy */
static void PrepareDataBuffers (uint8_t* psrc, uint8_t* pdst, uint32_t count, uint32_t msize);

/* Verifies memory DMA copy by comparing destination data with source */
static ADI_DMA_RESULT VerifyDataCopy (uint8_t* psrc, uint8_t* pdst, uint32_t count, uint32_t msize);

/* Callback for MDMA service */
static void MdmaCallback(void *pCBParam, uint32_t Event, void *pArg);

/*=============  EXTERNAL FUNCTION DECLARATIONS  =============*/

/*=============  MAIN FUNCTION DEFINITION  =============*/
int main(int argc, char *argv[])
{
    /* Time-out counter to make sure the example exits */
    volatile uint32_t   TimeOutCount = MEMCOPY_TIME_OUT_VAL;

    /* DMA Return code */
    ADI_DMA_RESULT      eResult = ADI_DMA_SUCCESS;

    /* To keep track of the test iteration */
    int test_iteration=0;

    /* To store source buffer start address */
    uint8_t* psrc;

    /* To store destination buffer start address */
   	uint8_t* pdst;

   	/* To store MSIZE value */
   	uint32_t msizevalue;

    /* Stores measured bandwidth */
   	uint32_t MeasuredBW;

    /* Initialize managed drivers and/or services */
    adi_initComponents();

    /* Initialize SPU */
    eResult = SpuInit();

    /* Initialize power service */
    if(adi_pwr_Init(0, 25000000)!=ADI_PWR_SUCCESS)
    {
    	eResult = ADI_DMA_FAILURE;
    }

    if (eResult == ADI_DMA_SUCCESS)
    {
		while(TestParamArray[test_iteration].TestIndex!=-1)
		{
			if(TestParamArray[test_iteration].TestIndex!=0)
			{
				msizevalue = 1<<(TestParamArray[test_iteration].eMsizeCfg>>BITP_DMA_CFG_MSIZE);

				DBG_MSG("\nTesting combination %d\n", TestParamArray[test_iteration].TestIndex);
				DBG_MSG("MDMA Stream no = %d\n", TestParamArray[test_iteration].eStreamID);
				DBG_MSG("MSIZE value = %d\n", msizevalue);
				DBG_MSG("Source channel = %d\n",TestParamArray[test_iteration].bSrcChannel );
				DBG_MSG("Target BW = %f MB/s \n", (float)TestParamArray[test_iteration].TargetBW/1000000.0);

				eResult = ADI_DMA_SUCCESS;

				/* Open a Memory DMA Stream */
				 eResult = adi_mdma_Open (TestParamArray[test_iteration].eStreamID,
										  &MemDmaStreamMem[0],
										  &hMemDmaStream,
										  &hSrcDmaChannel,
										  &hDestDmaChannel,
										  NULL,
										  NULL);

				/* IF (Failure) */
				if (eResult != ADI_DMA_SUCCESS)
				{
					DBG_MSG("Failed to open MDMA stream, Error Code: 0x%08X\n", eResult);
				}

				if (eResult == ADI_DMA_SUCCESS)
				{
					/* Set DMA Callback Function. No need to set for source channel since callback is not supported for it */
					eResult = adi_dma_UpdateCallback (hDestDmaChannel, MdmaCallback, hMemDmaStream);

					/* IF (Failure) */
					if (eResult != ADI_DMA_SUCCESS)
					{
						DBG_MSG("Failed to set DMA callback, Error Code: 0x%08X\n", eResult);
					}
				}

				/* Prepare data buffers */
				PrepareDataBuffers (SrcDataBuf, DestDataBuf, DMA_COUNT, msizevalue);

				/* Initialize flag */
				bBWMonitorExpried =false;

				if(TestParamArray[test_iteration].bSrcChannel)
				{
					/*Configure BW monitor*/
					adi_mdma_BWMonitor(hSrcDmaChannel,TestParamArray[test_iteration].TargetBW,DMA_COUNT*msizevalue);

					/* Limit the MDMA BW to less than expected so that BW monitor expiry interrupt occurs */
					adi_mdma_BWLimit(hSrcDmaChannel,TestParamArray[test_iteration].TargetBW-10, TestParamArray[test_iteration].eMsizeCfg );
				}
				else
				{
					/*Configure BW monitor*/
					adi_mdma_BWMonitor(hDestDmaChannel,TestParamArray[test_iteration].TargetBW,DMA_COUNT*msizevalue);

					/* Limit the MDMA BW to less than expected so that BW monitor expiry interrupt occurs */
					adi_mdma_BWLimit(hDestDmaChannel,TestParamArray[test_iteration].TargetBW-10, TestParamArray[test_iteration].eMsizeCfg );
				}

				/* IF (Success) */
				if (eResult == ADI_DMA_SUCCESS)
				{
					eResult = adi_mdma_Copy1D(
								hMemDmaStream,
								DestDataBuf,
								SrcDataBuf,
								TestParamArray[test_iteration].eMsizeCfg,
								DMA_COUNT);

					/* IF (Failure) */
					if (eResult != ADI_DMA_SUCCESS)
					{
						DBG_MSG("Failed to initiate One-shot 1D memory copy, Error Code: 0x%08X\n", eResult);
					}
				}

				/* IF (Success) */
				if (eResult == ADI_DMA_SUCCESS)
				{
					/* Reinitialize the TimeOutCount value */
					TimeOutCount = MEMCOPY_TIME_OUT_VAL;

					/* Wait until BW monitor expires*/
					while ((!bBWMonitorExpried) && (TimeOutCount))
					{
						/* Decrement time-out counter */
						TimeOutCount--;
					}
				}

				/* If no timeout */
				if(!TimeOutCount)
				{
					DBG_MSG("Time out\n");
					eResult = ADI_DMA_FAILURE;
				}


				/* IF (Failure) */
				if (adi_mdma_Close (hMemDmaStream, false) != ADI_DMA_SUCCESS)
				{
					DBG_MSG("Failed to close MDMA stream\n");
				}

				/* IF (Success) */
				if (eResult == ADI_DMA_SUCCESS)
				{
					DBG_MSG ("BW Monitor Expired!! Test combination %d passed\n\n",TestParamArray[test_iteration].TestIndex);
				}
				/* ELSE (Failure) */
				else
				{
					DBG_MSG ("Test combination %d failed\n\n",TestParamArray[test_iteration].TestIndex);
					TestInfo.FailedTestInfo[TestInfo.FailCount].TestIndex = TestParamArray[test_iteration].TestIndex;
					TestInfo.FailedTestInfo[TestInfo.FailCount++].ErrorCode = eResult;
				}
			}
			test_iteration++;
		}
	}

	/* IF (Success) */
	if ((eResult == ADI_DMA_SUCCESS)&&(TestInfo.FailCount == 0))
	{
		printf ("All done\n");
	}
	/* ELSE (Failure) */
	else
	{
		printf ("Failed for %d test combinations\n",TestInfo.FailCount);
	}

  return 0;
}

/*  Callback from MDMA Manager */
static void MdmaCallback(void *pCBParam, uint32_t Event, void *pArg)
{
    /* CASEOF (Event) */
    switch ((ADI_DMA_EVENT)Event)
    {
        /* CASE (Processed a one-shot/circular buffer) */
        case (ADI_DMA_EVENT_BUFFER_PROCESSED):
            /* Update memory copy status flag */
            bMemCopyInProgress = false;
            break;
        case (ADI_DMA_EVENT_ERROR_INT):
			bBWMonitorExpried =true;
        	break;

        default:
            break;
    }
}


/* Prepares data buffers for Memory DMA copy */
static void PrepareDataBuffers (uint8_t* psrc, uint8_t* pdst, uint32_t count, uint32_t msize)
{
    /* Loop variable */
    uint32_t    i;

    /* Generate Source data, Clear destination buffer */
    for (i = 0u; i < count*msize; i++)
    {
    	psrc[i]  = (uint8_t)rand();
    	pdst[i]  = 0;
    }
}


/* Verifies memory DMA copy by comparing destination data with source */
static ADI_DMA_RESULT VerifyDataCopy (uint8_t* psrc, uint8_t* pdst, uint32_t count, uint32_t msize)
{
    /* Loop variable */
    uint32_t        i;

    /* Compare the destination data with source */
    for (i = 0u; i < count*msize; i++)
    {
        /* IF (Destination data not same as source) */
        if (psrc[i] != pdst[i])
        {
            /* Return error */
            return (ADI_DMA_FAILURE);
        }
    }

    /* Return success */
    return (ADI_DMA_SUCCESS);
}

/* Initializes SPU */
static ADI_DMA_RESULT SpuInit(void)
{
	ADI_DMA_RESULT eResult = ADI_DMA_SUCCESS;

    /* Memory required for the SPU operation */
    uint8_t             SpuMemory[ADI_SPU_MEMORY_SIZE];

    /* SPU handle */
    ADI_SPU_HANDLE      hSpu;

    /* Initialize SPU Service */
    if(adi_spu_Init(0u, SpuMemory, NULL, NULL, &hSpu) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to initialize SPU service\n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA0 Source to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA0_SRC_DMA8_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 0 Source\n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA0 Destination to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA0_DST_DMA9_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 0 Destination\n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA1 Source to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA1_SRC_DMA18_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 1 Source\n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA1 Destination to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA1_DST_DMA19_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 1 Destination\n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA2 to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA2_SRC_DMA39_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 2 \n");
        eResult = ADI_DMA_FAILURE;
    }

    /* Make MDMA3 to generate secure transactions */
    if(adi_spu_EnableMasterSecure(hSpu, MDMA3_SRC_DMA43_SPU_PID, true) != ADI_SPU_SUCCESS)
    {
        DBG_MSG("Failed to enable Master secure for MDMA 2 \n");
        eResult = ADI_DMA_FAILURE;
    }

   return eResult;
}

/*****/
